
const express = require('express');  
const mysql = require('mysql2');     
const path = require("path");        


const app = express();


const PORT = 3000;


const rutasUsuarios = require('./rutas');


app.use(express.json());


app.use(express.static(path.join(__dirname, "public")));


const db = mysql.createConnection({
  host: 'localhost',  
  user: 'root',        
  password: '',        
  database: 'mi_app',  
  port: 3306           
});


db.connect(err => {
  if (err) {
    
    console.error('Error al conectar con MySQL:', err);
    return;
  }
  
  console.log('✅ Conectado a MySQL con XAMPP!');
  
  
  app.use('/', rutasUsuarios(db));
});


app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});


app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
}); 